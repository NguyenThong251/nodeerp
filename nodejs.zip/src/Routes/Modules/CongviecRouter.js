const CongviecRouter = [
  { _operation: "getListCongviec", source: "../Api/Modules/Congviec/getListCongviec" },
];

module.exports = CongviecRouter;