const LeadsRouter = [
  { _operation: "getLeadsReport", source: "../Api/Modules/Leads/getLeadsReport" },
];

module.exports = LeadsRouter;