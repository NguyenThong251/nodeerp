const vtigerLogin = async () => {
    const res = await axios.post(VTIGER_API_URL, new URLSearchParams({
        operation: 'login',
        username: VT_USER,
        accessKey: VT_ACCESS_KEY
    }));
    return res.data.result;
}

const findVRecord = async (req, userId, date, elementType) => {
    const query = `
      SELECT id FROM ${elementType}
      WHERE employees = '${userId}'
      AND date = '${date}'
      LIMIT 1;
    `;

    const res = await axios.post(VTIGER_API_URL, new URLSearchParams({
        operation: 'query',
        sessionName: req.sessionName,
        query
    }));

    return res.data.result?.[0] || null;
}


const saveVRecord = async (req, payload, elementType) => {
    return axios.post(VTIGER_API_URL, new URLSearchParams({
        operation: 'create',
        sessionName: req.sessionName,
        elementType,
        element: JSON.stringify(payload)
    }));
}


const updateVRecord = async (req, payload) => {
    return axios.post(VTIGER_API_URL, new URLSearchParams({
        operation: 'update',
        sessionName: req.sessionName,
        element: JSON.stringify(payload)
    }));
}

module.exports = {
    vtigerLogin,
    findVRecord,
    saveVRecord,
    updateVRecord
}