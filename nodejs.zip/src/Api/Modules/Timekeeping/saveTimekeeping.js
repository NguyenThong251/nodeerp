const mysql = require("@src/Services/MySQL/MySQLClient");
const { getTimekeepingData } = require("./getTimekeeping");
const { sanitizeRow, createResponse, formatDateTime, formatDate, addMinutesToTime, diffMinutes, roundMinutes, diffMinutesToTime } = require("@src/Utils/TimekeepingUtils");
const { vtigerLogin, findVRecord, saveVRecord, updateVRecord } = require("@src/Utils/HelperVtiger");


// ot_morning_limit/ot_night_limit dung de tinh  overtime morning va night bam vao nut checkin hien thi thong bao checkin ovt , co 1 api goij truoc ngay do nghi doi voi overtime nguyeên ngay off la se tao don ovt yeu cau capj nhat bam xac nhanj thi moi checkin/out
// kiem tra them dieu kien cho checkin vao khung gio nao ...
// save module vtiger 
const saveTimekeeping = async (req, res) => {
  try {
    // const userId = req.userId;
    const userId = 207;
    const userRole = req.userRole;
    const values = req.body.values;
    const { dateStart } = req.body;

    if (!values)
      return res.status(200).json(createResponse(false, "Values not found"));

    const settings = await getTimekeepingSettings(userId);
    if (!settings)
      return res.status(200).json(createResponse(false, "User not settings"));

    const today = formatDate();
    const timekeepingData = await getTimekeepingData(userId, dateStart);
    const timekeepingToday = timekeepingData?.[today];

    // CHECKIN
    if (!timekeepingToday?.checkin_time) {
      const checkIn = await handleCheckIn(userId, values, settings);
      if (!checkIn)
        return res.status(200).json(createResponse(false, "Đã quá thời gian chấm vào!"));
      return res.status(200).json(createResponse(true, checkIn));
    }

    // CHECKOUT
    if (!timekeepingToday?.checkout_time) {
      const checkInTime = new Date(timekeepingToday.checkin_time);
      const diffMinutes = Math.floor((Date.now() - checkInTime.getTime()) / 60000);

      if (diffMinutes <= 5)
        return res.status(200).json(createResponse(false, `Đợi ${6 - diffMinutes} phút trước khi chấm ra!`));

      const checkOut = await handleCheckOut(timekeepingToday, values, settings);
      if (!checkOut)
        return res.status(200).json(createResponse(false, "Chấm ra không thành công!"));
      return res.status(200).json(createResponse(true, checkOut));
    }

    // COMPLETED TIMEKEEPING TODAY
    return res.status(200).json(createResponse(true, timekeepingToday));
  } catch (error) {
    return res.status(500).json(createResponse(false, error.message || "Internal server error"));
  }
};





// HANDLE CHECK IN
async function handleCheckIn(userId, values, settings) {
  const now = new Date();
  const isCheckinTimeMin = now.toTimeString().slice(0, 8) > settings.checkin_time_min;


  const nowTimeStr = now.toTimeString().slice(0, 8);
  const graceLimit = addMinutesToTime(settings.checkin_time, settings.grace_time);

  // graceLimit: kIEM TRA DON XIN DI MUON VE SOM DA DUYET, KIEM TRA DON XIN NGHI NUA NGAY
  let lateMinutes = null;
  if (nowTimeStr > graceLimit) {
    lateMinutes = roundMinutes(
      diffMinutes(nowTimeStr, graceLimit),
      settings.lateearly_time_round
    );
  }


  if (isCheckinTimeMin) return false;
  const source = { check_in: values };

  const isWorkDay = checkWorkDay(settings.works_day);
  if (!isWorkDay) {
    const timeStart = now.toTimeString().slice(0, 8);


    const resOvertime = await saveOvertime(userId, source, now, timeStart);
  };

  // const query = "INSERT INTO vtiger_timekeeping_v2(created_by, checkin_time, late_minutes, source, create_time)VALUES (?, ?, ?, ?, ?)";
  const result = await mysql.query(query, [userId, now, lateMinutes, JSON.stringify(source), now]);

  return {
    id: result.insertId,
    created_by: userId,
    checkin_time: formatDateTime(),
    source: source
  };
}

// HANDLE CHECK OUT
async function handleCheckOut(timekeepingToday, values, settings) {
  if (!timekeepingToday?.id) return false;
  const now = new Date();
  const id = timekeepingToday.id;
  const source = { ...timekeepingToday.source, check_out: values };

  const nowTimeStr = now.toTimeString().slice(0, 8);
  const graceLimit = diffMinutesToTime(settings.checkout_time, settings.grace_time);

  // graceLimit: kIEM TRA DON XIN DI MUON VE SOM DA DUYET, KIEM TRA DON XIN NGHI NUA NGAY
  let earlyMinutes = null;
  if (nowTimeStr < graceLimit) {
    earlyMinutes = roundMinutes(
      -diffMinutes(nowTimeStr, graceLimit),
      settings.lateearly_time_round
    );
  }

  const query = "UPDATE vtiger_timekeeping_v2 SET checkout_time=?, early_minutes=?, source=? WHERE id = ?";
  const result = await mysql.query(query, [now, earlyMinutes, JSON.stringify(source), id]);
  if (!result) return false;

  return {
    id,
    created_by: timekeepingToday.created_by,
    checkin_time: formatDateTime(timekeepingToday.checkin_time),
    checkout_time: formatDateTime(),
    source
  };
}

async function getTimekeepingSettings(userId) {
  const query = "SELECT * FROM vtiger_timekeeping_settings WHERE employees IS NOT NULL AND FIND_IN_SET(?, employees)";
  const result = await mysql.query(query, [userId]);
  if (!result?.length) return null;
  return sanitizeRow(result[0]);
}


async function getOvertime(userId, date) {
  const query = "SELECT * FROM vtiger_tkpovertime WHERE employees = ? AND date = ?";
  const result = await mysql.query(query, [userId, date]);
  if (!result?.length) return null;
  return sanitizeRow(result[0]);
}

async function saveOvertime(userId, source, now, time_start, time_end) {

  const overtime = await getOvertime(userId, now);

  let query = "";
  let params = [];
  if (!overtime) {
    query = "INSERT INTO vtiger_tkpovertime(employees,date, time_start,time_end, source, create_time, create_by)VALUES (?, ?, ?, ?, ?, ?, ?)";
    params = [userId, formatDate(now), time_start, time_end, JSON.stringify(source), now, userId];
  }
  else {
    query = "UPDATE vtiger_tkpovertime SET time_start=?, time_end=?, source=?, modify_time=?, modify_by=? WHERE employees = ? AND date = ? ";
    params = [time_start, time_end, JSON.stringify(source), now, userId, formatDate(now)];
  }
  const result = await mysql.query(query, params);
  return result;
}

function checkWorkDay(works_day) {
  if (!works_day) return false;
  const today = new Date().getDay();
  const workDays = works_day.split(',').map(day => day.trim());
  return workDays.includes(String(today));
}



async function saveOvertime(req, source, now, time_start, time_end) {
  const date = formatDate(now);
  const elementType = 'TKPOvertime';
  const payload = {
    employees: req.user.vtigerUserId,
    date,
    time_start,
    time_end,
    source: JSON.stringify(source),
    assigned_user_id: req.user.vtigerUserId,
  };

  const existing = await findVRecord(req, elementType, date);

  if (!existing) {
    // CREATE
    const res = await saveVRecord(req, elementType, payload);
    return res.data.result;
  } else {
    // UPDATE
    payload.id = existing.id;
    const res = await updateVRecord(req, payload);
    return res.data.result;
  }
}





module.exports = saveTimekeeping; 