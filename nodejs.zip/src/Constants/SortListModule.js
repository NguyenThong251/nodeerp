const SortListModule = {
  Employee: ["cf_3139:asc"],
  Products: ["modifiedtime:desc"],
};

module.exports = SortListModule;
